# Shahyaau1 Visuals

Клиентский PvP-визуальный мод для Minecraft 1.21.4 + Fabric.

Автор: **shahyaau1**.

## Независимые визуальные модули

Каждая функция теперь находится в отдельной карточке ClickGUI и включается независимо:

- **Hit Particles** — собственные процедурные Spark, Star, Ring, Dust и Slash частицы, количество, lifetime и цвет.
- **Damage Numbers** — обычный урон, критический урон и лечение с отдельными цветами.
- **Jump Particles** — собственные частицы при прыжке/приземлении, стиль, количество и цвет.
- **China Hat** — отдельная настройка радиуса, высоты и цвета. Используется только кольцевой рендер без радиальных лучей.
- **Projectile Trajectory** — отдельная траектория стрел и жемчуга Энда с цветом и дальностью.
- **Combat Info** — Reach, Combo, CPS, Direction и Sprint/Sneak.
- **Crosshair** — размер, зазор, толщина, динамический hit-color и собственный цвет.
- **Keystrokes** — WASD/LMB/RMB и отдельный цвет.
- **Environment Visuals** — настройки окружения и particle limiter.
- **Entity Visuals** — отдельные настройки nametag, glint, Tab и scoreboard.
- **HUD** — watermark, координаты, Target HUD, Armor HUD и Module List.

## Палитры

В каждой карточке визуала доступны цвета `Theme`, `Red`, `Orange`, `Yellow`, `Green`, `Cyan`, `Blue`, `Purple`, `Pink` и `White`.

В ClickGUI добавлены темы: Periwinkle, Rose, Violet, Mint, Silver, Sunset, Ocean, Lavender, Lime, Ruby, Gold, Ice и Plasma.

## HUD Editor

Все элементы HUD можно перемещать через чат клавишей **T**: watermark, ник, координаты, Armor HUD, Target HUD, Module List, Crosshair, Keystrokes и Combat Info. ЛКМ перемещает, колесо меняет масштаб, ESC сохраняет конфигурацию.

## Установка

1. Fabric Loader 1.21.4.
2. Fabric API для 1.21.4.
3. Положи JAR в `.minecraft/mods`.
4. Удали старую версию мода.
5. Right Shift открывает ClickGUI.

Настройки сохраняются в `.minecraft/config/shahyaau1visuals.json`.
