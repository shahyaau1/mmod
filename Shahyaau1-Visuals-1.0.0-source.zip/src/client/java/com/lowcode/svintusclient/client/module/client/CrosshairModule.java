package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.BooleanSetting;
import dev.shahyaau1.visuals.client.module.setting.NumberSetting;
import dev.shahyaau1.visuals.client.module.setting.ModeSetting;
public final class CrosshairModule extends Module {
    public final ModeSetting color = add(new ModeSetting("Crosshair color", VisualModes.COLORS));
    public final NumberSetting size = add(new NumberSetting("Размер", 4f, 2f, 10f, 1f));
    public final NumberSetting gap = add(new NumberSetting("Зазор", 3f, 0f, 10f, 1f));
    public final NumberSetting thickness = add(new NumberSetting("Толщина", 1.5f, 1f, 4f, .5f));
    public final BooleanSetting dynamic = add(new BooleanSetting("Динамический цвет", true));
    public CrosshairModule() { super("Crosshair", "PvP-перекрестие с динамическим цветом", Category.COMBAT); enableByDefault(); }
}
