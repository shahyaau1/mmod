package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class EnvironmentVisualsModule extends Module { public final ModeSetting skyColor=add(new ModeSetting("Sky color",VisualModes.COLORS)); public final BooleanSetting noWeather=add(new BooleanSetting("No rain / snow",true)); public final BooleanSetting timeChanger=add(new BooleanSetting("Day time",false)); public final BooleanSetting particleLimiter=add(new BooleanSetting("Particle limiter",false)); public EnvironmentVisualsModule(){super("Environment Visuals","Time, weather and particle visibility",Category.RENDER);enableByDefault();} }
