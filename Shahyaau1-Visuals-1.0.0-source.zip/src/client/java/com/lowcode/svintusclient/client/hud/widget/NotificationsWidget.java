package dev.shahyaau1.visuals.client.hud.widget;

import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.hud.HudWidget;
import dev.shahyaau1.visuals.client.hud.Notifications;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.render.font.Fonts;
import net.minecraft.client.gui.DrawContext;

public class NotificationsWidget extends HudWidget {

    public NotificationsWidget() {
        super("notifications", "Уведомления", 1f, 0.9f);
    }

    @Override
    public boolean isVisible() {
        return ModuleManager.NOTIFICATIONS.isEnabled();
    }

    @Override
    public void setVisible(boolean v) {
        ModuleManager.NOTIFICATIONS.setEnabled(v);
    }

    @Override
    protected void layout(boolean editing) {
        w = Notifications.CARD_W;
        h = Notifications.CARD_H;
    }

    @Override
    protected void draw(DrawContext ctx, boolean editing) {
        if (editing && Notifications.isEmpty()) {
            Render2D.rect(ctx, x, y, w, h, 7f, 0x10FFFFFF);
            Render2D.outline(ctx, x, y, w, h, 7f, 0.8f, Theme.accent(0.35f));
            String text = "Здесь появятся уведомления";
            Fonts.REGULAR.drawCentered(ctx, text, x + (w - Fonts.REGULAR.width(text, 6f)) / 2f, y + h / 2f, 6f, Theme.TEXT_DIM);
        }
        Notifications.render(ctx, x, y, alignRight(), alignBottom());
    }
}
