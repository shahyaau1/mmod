package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.NumberSetting;

public class NotificationsModule extends Module {

    public final NumberSetting duration = add(new NumberSetting("Время показа", 2.5f, 1f, 6f, 0.5f));

    public NotificationsModule() {
        super("Notifications", "Уведомления о включении модулей", Category.CLIENT);
        enableByDefault();
    }
}
