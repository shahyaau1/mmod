package dev.shahyaau1.visuals.client.render;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer; import net.minecraft.util.Identifier;
public final class PigHead { private static final Identifier TEXTURE=Identifier.ofVanilla("textures/entity/pig/temperate_pig.png"); private PigHead(){} public static void draw(DrawContext c,float x,float y,float s){c.drawTexture(RenderLayer::getGuiTextured,TEXTURE,Math.round(x),Math.round(y),8,8,Math.round(s),Math.round(s),64,64);} }
