package dev.shahyaau1.visuals.client.module.client;
public final class VisualModes { public static final String[] COLORS={"Theme","Red","Orange","Yellow","Green","Cyan","Blue","Purple","Pink","White"}; private VisualModes(){} }
