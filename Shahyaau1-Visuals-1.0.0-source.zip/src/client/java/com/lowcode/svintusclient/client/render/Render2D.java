package dev.shahyaau1.visuals.client.render;
import dev.shahyaau1.visuals.client.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
public final class Render2D {
 private static float alpha=1f,pixelScale=2f; private Render2D(){}
 public static void setAlpha(float a){alpha=Math.max(0,Math.min(1,a));} public static float alpha(){return alpha;}
 public static void setPixelScale(float s){pixelScale=Math.max(.5f,s);} public static float pixelScale(){return pixelScale;}
 public static int applyAlpha(int c){return alpha>=1?c:Colors.fade(c,alpha);} private static int c(int c){return applyAlpha(c);}
 public static void rect(DrawContext x,float a,float b,float w,float h,float r,int col){if(w>0&&h>0)x.fill(Math.round(a),Math.round(b),Math.round(a+w),Math.round(b+h),c(col));}
 public static void rect(DrawContext x,float a,float b,float w,float h,float r,int tl,int tr,int br,int bl){gradientH(x,a,b,w,h,r,tl,tr);}
 public static void gradientH(DrawContext x,float a,float b,float w,float h,float r,int l,int rr){if(w>0&&h>0)x.fillGradient(Math.round(a),Math.round(b),Math.round(a+w),Math.round(b+h),c(l),c(rr));}
 public static void gradientV(DrawContext x,float a,float b,float w,float h,float r,int t,int bot){if(w>0&&h>0)x.fillGradient(Math.round(a),Math.round(b),Math.round(a+w),Math.round(b+h),c(t),c(bot));}
 public static void outline(DrawContext x,float a,float b,float w,float h,float r,float th,int col){int t=Math.max(1,Math.round(th));rect(x,a,b,w,t,r,col);rect(x,a,b+h-t,w,t,r,col);rect(x,a,b,t,h,r,col);rect(x,a+w-t,b,t,h,r,col);}
 public static void outline(DrawContext x,float a,float b,float w,float h,float r,float th,int tl,int tr,int br,int bl){outline(x,a,b,w,h,r,th,tl);}
 public static void outlineGradientH(DrawContext x,float a,float b,float w,float h,float r,float th,int l,int rr){outline(x,a,b,w,h,r,th,l);}
 public static void outlineGradientV(DrawContext x,float a,float b,float w,float h,float r,float th,int t,int bot){outline(x,a,b,w,h,r,th,t);}
 public static void shadow(DrawContext x,float a,float b,float w,float h,float r,float soft,int col){rect(x,a-soft/3,b-soft/3,w+soft*2/3,h+soft*2/3,r,col);}
 public static void circle(DrawContext x,float cx,float cy,float r,int col){rect(x,cx-r,cy-r,r*2,r*2,r,col);} public static void circleOutline(DrawContext x,float cx,float cy,float r,float t,int col){outline(x,cx-r,cy-r,r*2,r*2,r,t,col);}
 public static boolean blur(DrawContext x,float a,float b,float w,float h,float r,int tint){return false;}
 public static void texture(DrawContext x,TextureSetup s,float a,float b,float w,float h,float u0,float v0,float u1,float v1,int col){if(s!=null&&s.texture()!=null)x.drawTexture(RenderLayer::getGuiTextured,s.texture(),Math.round(a),Math.round(b),u0*64,v0*64,Math.round(w),Math.round(h),64,64);}
 public static void texturedQuads(DrawContext x,TextureSetup s,float[] q,int count,int col){}
 public static void pushScissor(DrawContext x,float a,float b,float w,float h){x.enableScissor(Math.round(a),Math.round(b),Math.round(a+w),Math.round(b+h));} public static void popScissor(DrawContext x){x.disableScissor();}
 public static float snap(float v){return Math.round(v*pixelScale)/pixelScale;}
}
