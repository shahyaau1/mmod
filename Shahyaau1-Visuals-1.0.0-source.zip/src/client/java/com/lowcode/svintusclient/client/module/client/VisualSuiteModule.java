package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.BooleanSetting;
import dev.shahyaau1.visuals.client.module.setting.NumberSetting;

/** Settings for the advanced PvP visual suite. */
public final class VisualSuiteModule extends Module {
    public final BooleanSetting hitBlink = add(new BooleanSetting("Hit Color / Blink", true));
    public final BooleanSetting reach = add(new BooleanSetting("Reach Display", true));
    public final BooleanSetting combo = add(new BooleanSetting("Combo Counter", true));
    public final BooleanSetting tntTimer = add(new BooleanSetting("TNT Timer", true));
    public final BooleanSetting pearlTrajectory = add(new BooleanSetting("Pearl Trajectory", true));
    public final BooleanSetting cleanScoreboard = add(new BooleanSetting("Clean Scoreboard", false));
    public final BooleanSetting tabInfo = add(new BooleanSetting("Tab Ping / Health", true));
    public final BooleanSetting nametagHealth = add(new BooleanSetting("Nametag Health", true));
    public final BooleanSetting itemPhysics = add(new BooleanSetting("Item Physics", true));
    public final BooleanSetting customGlint = add(new BooleanSetting("Custom Glint", true));
    public final BooleanSetting timeChanger = add(new BooleanSetting("Time Changer", false));
    public final BooleanSetting noWeather = add(new BooleanSetting("No Rain / Snow", true));
    public final BooleanSetting motionBlur = add(new BooleanSetting("Motion Blur", false));
    public final BooleanSetting particleChanger = add(new BooleanSetting("Particle Changer", true));
    public final BooleanSetting directionHud = add(new BooleanSetting("Direction HUD", true));
    public final BooleanSetting cps = add(new BooleanSetting("CPS Counter", true));
    public final BooleanSetting sprintSneak = add(new BooleanSetting("Sprint / Sneak", true));
    public final BooleanSetting directionalDamage = add(new BooleanSetting("Directional Damage", true));
    public final NumberSetting hitBlinkTime = add(new NumberSetting("Blink duration", .35f, .05f, 1.5f, .05f));
    public final NumberSetting particleMultiplier = add(new NumberSetting("Particle amount", 1f, 0f, 3f, .25f));
    public VisualSuiteModule() {
        super("Advanced Visuals", "Combat, entity, environment and information visual controls", Category.RENDER);
        enableByDefault();
    }
}
