package dev.shahyaau1.visuals.client;

import dev.shahyaau1.visuals.client.combat.CombatVisuals;
import dev.shahyaau1.visuals.client.gui.ClickGuiScreen;
import dev.shahyaau1.visuals.client.hud.HudManager;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

public class Shahyaau1VisualsClient implements ClientModInitializer {

    public static final String MOD_ID = "shahyaau1visuals";
    public static final Logger LOGGER = LoggerFactory.getLogger("Shahyaau1 Visuals");

    private static final Set<Integer> HELD_KEYS = new HashSet<>();
    private static KeyBinding clickGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        HudManager.register();
        Config.load();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());

        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.shahyaau1visuals.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.misc"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            CombatVisuals.tick(client);
            while (clickGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new ClickGuiScreen());
            }
            handleModuleBinds(client);
        });
        WorldRenderEvents.END.register(CombatVisuals::render);
    }

    private static void handleModuleBinds(MinecraftClient client) {
        for (Module module : ModuleManager.all()) {
            int key = module.getKey();
            if (key == GLFW.GLFW_KEY_UNKNOWN) continue;
            boolean down = InputUtil.isKeyPressed(client.getWindow().getHandle(), key);
            if (down && HELD_KEYS.add(key)) {
                if (client.currentScreen == null) module.toggle();
            } else if (!down) {
                HELD_KEYS.remove(key);
            }
        }
    }

    public static int clickGuiKey() {
        return KeyBindingHelper.getBoundKeyOf(clickGuiKey).getCode();
    }
}
