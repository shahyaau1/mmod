package dev.shahyaau1.visuals.client.hud;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
public final class HudDraw {
 private HudDraw() {}
 public static void glass(DrawContext c,float x,float y,float w,float h,float r){Render2D.shadow(c,x,y,w,h,r,8,0x60000000);Render2D.rect(c,x,y,w,h,r,0xE00E0F14);Render2D.gradientV(c,x,y,w,Math.min(h,14),r,0x0AFFFFFF,0);Render2D.outlineGradientV(c,x,y,w,h,r,.8f,0x24FFFFFF,0x08FFFFFF);}
 public static void item(DrawContext c,ItemStack s,float x,float y,float z){if(!s.isEmpty())c.drawItem(s,Math.round(x),Math.round(y));}
 public static void durability(DrawContext c,ItemStack s,float x,float y,float w){if(s.isEmpty()||!s.isItemBarVisible())return;float t=s.getItemBarStep()/13f;Render2D.rect(c,x,y,w,1.6f,.8f,0x50000000);Render2D.rect(c,x,y,Math.max(1.6f,w*t),1.6f,.8f,0xFF000000|s.getItemBarColor());}
 public static int durabilityPercent(ItemStack s){if(s.isEmpty()||!s.isDamageable()||s.getMaxDamage()<=0)return -1;return Math.round(100f*(s.getMaxDamage()-s.getDamage())/s.getMaxDamage());}
 public static void head(DrawContext c,LivingEntity e,float x,float y,float z){int scale=Math.max(4,Math.round(z*.9f/Math.max(.6f,e.getHeight())));InventoryScreen.drawEntity(c,Math.round(x),Math.round(y),Math.round(x+z),Math.round(y+z),scale,.0625f,x+z/2f+6,y+z*.35f,e);}
}
