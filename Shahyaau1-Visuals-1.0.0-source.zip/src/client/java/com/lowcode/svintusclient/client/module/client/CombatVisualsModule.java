package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.BooleanSetting;
import dev.shahyaau1.visuals.client.module.setting.ModeSetting;
import dev.shahyaau1.visuals.client.module.setting.NumberSetting;

public final class CombatVisualsModule extends Module {
    public final BooleanSetting hitParticles = add(new BooleanSetting("Частицы попаданий", true));
    public final ModeSetting hitParticleType = add(new ModeSetting("Тип частиц", "Crit", "Damage", "Heart", "Flame", "Cloud", "Soul"));
    public final NumberSetting particleLifetime = add(new NumberSetting("Время частиц", 1.25f, .4f, 3f, .05f));
    public final NumberSetting particleAmount = add(new NumberSetting("Количество частиц", 8f, 1f, 24f, 1f));
    public final BooleanSetting damageNumbers = add(new BooleanSetting("Числа урона", true));
    public final BooleanSetting criticalEffects = add(new BooleanSetting("Критические эффекты", true));
    public final BooleanSetting trajectory = add(new BooleanSetting("Траектория снарядов", true));
    public final BooleanSetting jumpParticles = add(new BooleanSetting("Jump Particles", true));
    public final ModeSetting jumpParticleType = add(new ModeSetting("Jump particle", "Cloud", "Crit", "Flame", "Soul"));
    public final BooleanSetting chinaHat = add(new BooleanSetting("China Hat", true));
    public final NumberSetting hatRadius = add(new NumberSetting("Hat radius", .65f, .25f, 1.5f, .05f));
    public final NumberSetting hatHeight = add(new NumberSetting("Hat height", .25f, .05f, .8f, .05f));
    public final NumberSetting damageLifetime = add(new NumberSetting("Время урона", 2f, .5f, 4f, .25f));
    public final NumberSetting trajectoryRange = add(new NumberSetting("Дальность траектории", 32f, 8f, 64f, 4f));
    public CombatVisualsModule() {
        super("Combat Visuals", "Particles, hit effects, China Hat, jump effects and trajectory", Category.COMBAT);
        enableByDefault();
    }
}
