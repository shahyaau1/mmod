package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class HitParticlesModule extends Module { public final ModeSetting style=add(new ModeSetting("Particle style","Spark","Star","Ring","Dust","Slash")); public final ModeSetting color=add(new ModeSetting("Particle color",VisualModes.COLORS)); public final NumberSetting amount=add(new NumberSetting("Amount",10f,1f,32f,1f)); public final NumberSetting lifetime=add(new NumberSetting("Lifetime",1.2f,.2f,3f,.05f)); public HitParticlesModule(){super("Hit Particles","Custom procedural particles when a target is hit",Category.COMBAT);enableByDefault();} }
