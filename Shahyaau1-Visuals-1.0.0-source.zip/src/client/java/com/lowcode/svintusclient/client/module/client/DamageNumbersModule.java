package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class DamageNumbersModule extends Module { public final ModeSetting color=add(new ModeSetting("Damage color",VisualModes.COLORS)); public final ModeSetting criticalColor=add(new ModeSetting("Critical color",VisualModes.COLORS)); public final ModeSetting healColor=add(new ModeSetting("Heal color",VisualModes.COLORS)); public final NumberSetting lifetime=add(new NumberSetting("Lifetime",2f,.4f,5f,.1f)); public DamageNumbersModule(){super("Damage Numbers","Floating damage and heal values",Category.COMBAT);enableByDefault();} }
