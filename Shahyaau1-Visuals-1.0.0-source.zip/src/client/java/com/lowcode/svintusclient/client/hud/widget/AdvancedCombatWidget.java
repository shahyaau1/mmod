package dev.shahyaau1.visuals.client.hud.widget;

import dev.shahyaau1.visuals.client.combat.CombatVisuals;
import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.hud.HudDraw;
import dev.shahyaau1.visuals.client.hud.HudWidget;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.render.font.Fonts;
import dev.shahyaau1.visuals.client.util.VisualColors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.TntEntity;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayDeque;
import java.util.Deque;

public final class AdvancedCombatWidget extends HudWidget {
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    public AdvancedCombatWidget() { super("advanced-combat", "Combat Info", .02f, .38f); }
    public boolean isVisible() { return ModuleManager.COMBAT_INFO.isEnabled(); }
    public void setVisible(boolean visible) { ModuleManager.COMBAT_INFO.setEnabled(visible); }
    protected void layout(boolean editing) { w=164f; h=42f; }
    protected void draw(DrawContext ctx, boolean editing) {
        MinecraftClient client=MinecraftClient.getInstance(); long now=System.currentTimeMillis();
        if (client.getWindow().getHandle()!=0) { if(GLFW.glfwGetMouseButton(client.getWindow().getHandle(),GLFW.GLFW_MOUSE_BUTTON_LEFT)==GLFW.GLFW_PRESS) leftClicks.addLast(now); if(GLFW.glfwGetMouseButton(client.getWindow().getHandle(),GLFW.GLFW_MOUSE_BUTTON_RIGHT)==GLFW.GLFW_PRESS) rightClicks.addLast(now); }
        while(!leftClicks.isEmpty()&&now-leftClicks.peekFirst()>1000)leftClicks.removeFirst(); while(!rightClicks.isEmpty()&&now-rightClicks.peekFirst()>1000)rightClicks.removeFirst();
        HudDraw.glass(ctx,x,y,w,h,6f);
        String line1=String.format(java.util.Locale.ROOT,"Reach %.1f  Combo %d",CombatVisuals.lastReach(),CombatVisuals.comboCount());
        String dir=client.player==null?"":client.player.getHorizontalFacing().asString().toUpperCase();
        int tnt=client.world==null?0:client.world.getEntitiesByClass(TntEntity.class,client.player.getBoundingBox().expand(48),e->true).size();
        String line2="LMB "+leftClicks.size()+"  RMB "+rightClicks.size()+"  "+dir;
        String line3=(client.player!=null&&client.player.isSprinting()?"SPRINT":"WALK")+"  "+(client.player!=null&&client.player.isSneaking()?"SNEAK":"STAND")+"  TNT "+tnt;
        int infoColor=VisualColors.get(ModuleManager.COMBAT_INFO.color.get());
        Fonts.SEMIBOLD.draw(ctx,line1,x+7f,y+7f,6.2f,Theme.TEXT); Fonts.REGULAR.draw(ctx,line2,x+7f,y+18f,5.7f,Theme.TEXT_DIM); Fonts.REGULAR.draw(ctx,line3,x+7f,y+29f,5.7f,infoColor);
        Render2D.rect(ctx,x+w-4f,y+5f,1.5f,h-10f,1f,infoColor);
    }
}
