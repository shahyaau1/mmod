package dev.shahyaau1.visuals.client.hud;

import dev.shahyaau1.visuals.client.Config;
import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.render.font.Fonts;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;

/** Universal HUD editor: every visible widget can be dragged while chat is open. */
public final class HudEditor {
    private static HudWidget dragging;
    private static float grabX, grabY;
    private HudEditor() {}
    public static boolean isEditing() { return MinecraftClient.getInstance().currentScreen instanceof ChatScreen; }
    static boolean isDragging(HudWidget widget) { return dragging == widget; }
    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!(screen instanceof ChatScreen)) return;
            ScreenMouseEvents.allowMouseClick(screen).register((s, mx, my, button) -> !mouseClicked(mx, my, button));
            ScreenMouseEvents.allowMouseRelease(screen).register((s, mx, my, button) -> !mouseReleased(mx, my, button));
            ScreenMouseEvents.allowMouseScroll(screen).register((s, mx, my, horizontal, vertical) -> {
                HudWidget hovered = widgetAt((float) mx, (float) my);
                if (dragging == null && hovered != null) dragging = hovered;
                if (dragging == null) return true;
                dragging.setScale(dragging.getScale() + (vertical > 0 ? .05f : -.05f));
                Config.save(); return false;
            });
            ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> render(ctx, mx, my));
            ScreenEvents.remove(screen).register(s -> { if (dragging != null) Config.save(); dragging = null; });
        });
    }
    private static void refresh(DrawContext ctx) {
        float sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudWidget w : HudManager.widgets()) {
            if (!HudManager.isEditable(w)) continue;
            w.layout(true);
            if (w != dragging) w.place(sw, sh);
        }
    }
    private static HudWidget widgetAt(float mx, float my) {
        HudWidget hit = null;
        var widgets = HudManager.widgets();
        for (int i = widgets.size() - 1; i >= 0; i--) {
            HudWidget w = widgets.get(i);
            if (HudManager.isEditable(w) && w.contains(mx, my)) hit = w;
        }
        return hit;
    }
    private static boolean mouseClicked(double mx, double my, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return false;
        MinecraftClient client = MinecraftClient.getInstance();
        float sw = client.getWindow().getScaledWidth(), sh = client.getWindow().getScaledHeight();
        for (HudWidget w : HudManager.widgets()) { if (HudManager.isEditable(w)) { w.layout(true); if (w != dragging) w.place(sw, sh); } }
        HudWidget w = widgetAt((float) mx, (float) my);
        if (w == null) return false;
        dragging = w; grabX = (float) mx - w.x; grabY = (float) my - w.y; return true;
    }
    private static boolean mouseReleased(double mx, double my, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || dragging == null) return false;
        dragging = null; Config.save(); return true;
    }
    private static void render(DrawContext ctx, int mouseX, int mouseY) {
        if (!isEditing()) return;
        refresh(ctx);
        float sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        if (dragging != null) dragging.moveTo(mouseX - grabX, mouseY - grabY, sw, sh);
        HudWidget hovered = widgetAt(mouseX, mouseY);
        for (HudWidget w : HudManager.widgets()) {
            if (!HudManager.isEditable(w)) continue;
            boolean selected = w == dragging || w == hovered;
            Render2D.outline(ctx, w.x - 2f, w.y - 2f, Math.max(8f, w.scaledW()) + 4f, Math.max(8f, w.scaledH()) + 4f, 4f, selected ? 1.2f : .7f, selected ? Theme.accent() : Theme.accent(.35f));
            if (selected) Fonts.REGULAR.draw(ctx, w.title + " • ЛКМ — переместить, колесо — масштаб", w.x, Math.max(10f, w.y - 12f), 6f, Theme.TEXT);
        }
        String hint = "HUD EDITOR • все элементы перемещаются ЛКМ • колесо — масштаб • ESC — закрыть";
        Render2D.rect(ctx, 8f, sh - 22f, Fonts.REGULAR.width(hint, 6f) + 12f, 16f, 5f, 0xCC0B0D12);
        Fonts.REGULAR.draw(ctx, hint, 14f, sh - 18f, 6f, Theme.TEXT);
    }
}
