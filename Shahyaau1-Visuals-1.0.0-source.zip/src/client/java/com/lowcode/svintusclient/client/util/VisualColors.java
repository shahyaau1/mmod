package dev.shahyaau1.visuals.client.util;
import dev.shahyaau1.visuals.client.gui.Theme;
public final class VisualColors { private VisualColors(){} public static int get(String name){ return switch(name){case "Red"->0xFFFF4D67;case "Orange"->0xFFFF9F43;case "Yellow"->0xFFFFD166;case "Green"->0xFF62E294;case "Cyan"->0xFF55DDE0;case "Blue"->0xFF5E8BFF;case "Purple"->0xFFAA7BFF;case "Pink"->0xFFFF78C8;case "White"->0xFFFFFFFF;default->Theme.accent();};} }
