package dev.shahyaau1.visuals.client.hud.widget;

import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.hud.HudDraw;
import dev.shahyaau1.visuals.client.hud.HudWidget;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.render.font.Fonts;
import dev.shahyaau1.visuals.client.util.VisualColors;
import dev.shahyaau1.visuals.client.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class KeystrokesWidget extends HudWidget {
    private final int[] keys={GLFW.GLFW_KEY_W,GLFW.GLFW_KEY_A,GLFW.GLFW_KEY_S,GLFW.GLFW_KEY_D};
    public KeystrokesWidget(){super("keystrokes","Keystrokes",.02f,.72f);}
    public boolean isVisible(){return ModuleManager.KEYSTROKES.isEnabled();}
    public void setVisible(boolean v){ModuleManager.KEYSTROKES.setEnabled(v);}
    protected void layout(boolean editing){w=78f;h=70f;}
    protected void draw(DrawContext ctx,boolean editing){
        HudDraw.glass(ctx,x,y,w,h,7f); float cell=21f,gap=3f, ox=x+6f,oy=y+6f;
        cell(ctx,"W",ox+cell+gap,oy,keyDown(keys[0])); cell(ctx,"A",ox,oy+cell+gap,keyDown(keys[1])); cell(ctx,"S",ox+cell+gap,oy+cell+gap,keyDown(keys[2])); cell(ctx,"D",ox+2*(cell+gap),oy+cell+gap,keyDown(keys[3]));
        boolean l=mouse(GLFW.GLFW_MOUSE_BUTTON_LEFT), r=mouse(GLFW.GLFW_MOUSE_BUTTON_RIGHT);
        wideCell(ctx,"LMB",ox,oy+2*(cell+gap),l); wideCell(ctx,"RMB",ox+cell*1.5f+gap,oy+2*(cell+gap),r);
    }
    private void cell(DrawContext c,String label,float x,float y,boolean down){int col=VisualColors.get(ModuleManager.KEYSTROKES.color.get());float w=label.length()>1?31.5f:21f;Render2D.rect(c,x,y,w,21f,4f,down?Colors.withAlpha(col,.45f):0x16FFFFFF);Render2D.outline(c,x,y,w,21f,4f,.7f,down?Colors.withAlpha(col,.8f):0x18FFFFFF);Fonts.SEMIBOLD.drawCentered(c,label,x+w/2f,y+10.5f,5.5f,down?Theme.TEXT:Theme.TEXT_DIM);}
    private void wideCell(DrawContext c,String label,float x,float y,boolean down){int col=VisualColors.get(ModuleManager.KEYSTROKES.color.get());float w=31.5f;Render2D.rect(c,x,y,w,21f,4f,down?Colors.withAlpha(col,.45f):0x16FFFFFF);Render2D.outline(c,x,y,w,21f,4f,.7f,down?Colors.withAlpha(col,.8f):0x18FFFFFF);Fonts.SEMIBOLD.drawCentered(c,label,x+w/2f,y+10.5f,5.5f,down?Theme.TEXT:Theme.TEXT_DIM);}
    private boolean keyDown(int k){return InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow().getHandle(),k);}
    private boolean mouse(int b){return GLFW.glfwGetMouseButton(MinecraftClient.getInstance().getWindow().getHandle(),b)==GLFW.GLFW_PRESS;}
}
