package dev.shahyaau1.visuals.client.combat;

import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.module.client.*;
import dev.shahyaau1.visuals.client.util.VisualColors;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import java.util.*;

/** Independent procedural visual runtime. It does not use vanilla particle entities. */
public final class CombatVisuals {
    private record Spark(Vec3d pos, Vec3d vel, long born, long life, int color, String style) {}
    private record Damage(Vec3d pos, String text, int color, long born, long life) {}
    private static final List<Spark> SPARKS=new ArrayList<>();
    private static final List<Damage> DAMAGE=new ArrayList<>();
    private static final Map<UUID,Float> HEALTH=new HashMap<>();
    private static final List<Vec3d> TRAJECTORY=new ArrayList<>();
    private static UUID comboTarget; private static int combo; private static float reach; private static boolean wasGround=true; private static long lastJump;
    private CombatVisuals(){}
    public static void tick(MinecraftClient c){
        if(c.world==null||c.player==null)return;
        if(ModuleManager.HIT_PARTICLES.isEnabled()||ModuleManager.DAMAGE_NUMBERS.isEnabled()){
            for(LivingEntity e:c.world.getEntitiesByClass(LivingEntity.class,c.player.getBoundingBox().expand(32),x->x!=c.player&&x.isAlive())){
                float hp=e.getHealth()+e.getAbsorptionAmount();
                Float old=HEALTH.put(e.getUuid(),hp);
                if(old!=null&&Math.abs(hp-old)>.01f){float delta=hp-old; boolean crit=delta<0&&!c.player.isOnGround()&&c.player.fallDistance>0; if(delta<0){if(!e.getUuid().equals(comboTarget))combo=0;comboTarget=e.getUuid();combo++;reach=c.player.distanceTo(e);} spawn(c,e,Math.abs(delta),crit,delta>0);}
            }
        }
        if(ModuleManager.JUMP_PARTICLES.isEnabled()&&wasGround!=c.player.isOnGround()&&System.currentTimeMillis()-lastJump>120){lastJump=System.currentTimeMillis(); for(int i=0;i<Math.round(ModuleManager.JUMP_PARTICLES.amount.get());i++)addSpark(c.player.getPos().add((c.world.random.nextDouble()-.5)*.8,.05,(c.world.random.nextDouble()-.5)*.8),ModuleManager.JUMP_PARTICLES.style.get(),VisualColors.get(ModuleManager.JUMP_PARTICLES.color.get()),.9f);}
        wasGround=c.player.isOnGround(); updateTrajectory(c);
    }
    private static void spawn(MinecraftClient c,LivingEntity e,float amount,boolean crit,boolean heal){Vec3d p=e.getPos().add(0,e.getHeight()+.15,0); if(ModuleManager.HIT_PARTICLES.isEnabled())for(int i=0;i<Math.round(ModuleManager.HIT_PARTICLES.amount.get());i++)addSpark(p,ModuleManager.HIT_PARTICLES.style.get(),VisualColors.get(ModuleManager.HIT_PARTICLES.color.get()),ModuleManager.HIT_PARTICLES.lifetime.get()); if(ModuleManager.DAMAGE_NUMBERS.isEnabled()){int col=VisualColors.get(heal?ModuleManager.DAMAGE_NUMBERS.healColor.get():crit?ModuleManager.DAMAGE_NUMBERS.criticalColor.get():ModuleManager.DAMAGE_NUMBERS.color.get());DAMAGE.add(new Damage(p,(heal?"+":"-")+String.format(Locale.ROOT,"%.1f",amount),col,System.currentTimeMillis(),(long)(ModuleManager.DAMAGE_NUMBERS.lifetime.get()*1000)));}}
    private static void addSpark(Vec3d p,String style,int color,float seconds){double a=Math.random()*Math.PI*2;SPARKS.add(new Spark(p,new Vec3d(Math.cos(a)*.08,.04+Math.random()*.13,Math.sin(a)*.08),System.currentTimeMillis(),(long)(seconds*1000),color,style));}
    private static void updateTrajectory(MinecraftClient c){TRAJECTORY.clear();if(!ModuleManager.TRAJECTORY.isEnabled())return;ProjectileEntity best=null;double d0=ModuleManager.TRAJECTORY.range.get();for(ProjectileEntity e:c.world.getEntitiesByClass(ProjectileEntity.class,c.player.getBoundingBox().expand(d0),x->(x instanceof ArrowEntity&&ModuleManager.TRAJECTORY.arrows.get())||(x instanceof EnderPearlEntity&&ModuleManager.TRAJECTORY.pearls.get()))){double d=c.player.distanceTo(e);if(d<d0){d0=d;best=e;}}if(best==null)return;Vec3d p=best.getPos(),v=best.getVelocity();for(int i=0;i<36;i++){TRAJECTORY.add(p);BlockPos b=BlockPos.ofFloored(p);if(c.world.getBlockState(b).isSolidBlock(c.world,b))break;v=v.multiply(.99).add(0,-.03,0);p=p.add(v);}}
    public static float lastReach(){return reach;} public static int comboCount(){return combo;}
    public static void render(WorldRenderContext ctx){MinecraftClient c=MinecraftClient.getInstance();if(c.world==null||c.player==null)return;renderSparks(ctx,c);renderDamage(ctx,c);renderTrajectory(ctx,c);renderHat(ctx,c);}
    private static void renderSparks(WorldRenderContext ctx,MinecraftClient c){long now=System.currentTimeMillis();SPARKS.removeIf(s->now-s.born()>s.life());Camera cam=c.gameRenderer.getCamera();Vec3d cp=cam.getPos();Matrix4f m=ctx.matrixStack().peek().getPositionMatrix();VertexConsumer out=ctx.consumers().getBuffer(RenderLayer.getLines());for(Spark s:SPARKS){float t=(now-s.born())/(float)s.life();Vec3d p=s.pos().add(s.vel().multiply(t*12)).subtract(cp);float r=.06f*(1-t);if(s.style().equals("Ring")){for(int i=0;i<8;i++){double a=i*Math.PI/4,b=(i+1)*Math.PI/4;line(out,m,p.add(Math.cos(a)*r,0,Math.sin(a)*r),p.add(Math.cos(b)*r,0,Math.sin(b)*r),s.color());}}else{line(out,m,p.add(-r,0,0),p.add(r,0,0),s.color());line(out,m,p.add(0,-r,0),p.add(0,r,0),s.color());if(s.style().equals("Star")){line(out,m,p.add(0,0,-r),p.add(0,0,r),s.color());line(out,m,p.add(-r,-r,0),p.add(r,r,0),s.color());}}}}
    private static void renderTrajectory(WorldRenderContext ctx,MinecraftClient c){if(TRAJECTORY.size()<2)return;Vec3d cp=c.gameRenderer.getCamera().getPos();Matrix4f m=ctx.matrixStack().peek().getPositionMatrix();VertexConsumer out=ctx.consumers().getBuffer(RenderLayer.getLines());int col=VisualColors.get(ModuleManager.TRAJECTORY.color.get());for(int i=1;i<TRAJECTORY.size();i++)line(out,m,TRAJECTORY.get(i-1).subtract(cp),TRAJECTORY.get(i).subtract(cp),col);}
    private static void renderHat(WorldRenderContext ctx,MinecraftClient c){if(!ModuleManager.CHINA_HAT.isEnabled())return;Vec3d cp=c.gameRenderer.getCamera().getPos(),center=c.player.getPos().add(0,c.player.getHeight()+ModuleManager.CHINA_HAT.height.get(),0);Matrix4f m=ctx.matrixStack().peek().getPositionMatrix();VertexConsumer out=ctx.consumers().getBuffer(RenderLayer.getLines());int col=VisualColors.get(ModuleManager.CHINA_HAT.color.get());float r=ModuleManager.CHINA_HAT.radius.get();for(int i=0;i<48;i++){double a=i*Math.PI*2/48,b=(i+1)*Math.PI*2/48;line(out,m,center.add(Math.cos(a)*r,0,Math.sin(a)*r).subtract(cp),center.add(Math.cos(b)*r,0,Math.sin(b)*r).subtract(cp),col);}}
    private static void renderDamage(WorldRenderContext ctx,MinecraftClient c){long now=System.currentTimeMillis();DAMAGE.removeIf(d->now-d.born()>d.life());if(DAMAGE.isEmpty()||!ModuleManager.DAMAGE_NUMBERS.isEnabled())return;Camera cam=c.gameRenderer.getCamera();Vec3d cp=cam.getPos();VertexConsumerProvider v=ctx.consumers();MatrixStack ms=ctx.matrixStack();for(Damage d:DAMAGE){float t=(now-d.born())/(float)d.life();Vec3d p=d.pos().add(0,.7*t,0).subtract(cp);ms.push();ms.translate(p.x,p.y,p.z);ms.multiply(cam.getRotation());ms.scale(-.025f,-.025f,.025f);c.textRenderer.draw(Text.literal(d.text()),-c.textRenderer.getWidth(d.text())/2f,0,d.color(),true,ms.peek().getPositionMatrix(),v,net.minecraft.client.font.TextRenderer.TextLayerType.SEE_THROUGH,0,15728880);ms.pop();}}
    private static void line(VertexConsumer o,Matrix4f m,Vec3d a,Vec3d b,int col){float r=((col>>16)&255)/255f,g=((col>>8)&255)/255f,bl=(col&255)/255f;o.vertex(m,(float)a.x,(float)a.y,(float)a.z).color(r,g,bl,1).normal(0,1,0);o.vertex(m,(float)b.x,(float)b.y,(float)b.z).color(r,g,bl,1).normal(0,1,0);}
}
