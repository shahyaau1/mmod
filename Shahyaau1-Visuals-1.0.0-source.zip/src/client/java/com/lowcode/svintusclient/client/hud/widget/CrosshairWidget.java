package dev.shahyaau1.visuals.client.hud.widget;

import dev.shahyaau1.visuals.client.gui.Theme;
import dev.shahyaau1.visuals.client.hud.HudWidget;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.Render2D;
import dev.shahyaau1.visuals.client.util.VisualColors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public final class CrosshairWidget extends HudWidget {
    public CrosshairWidget() { super("crosshair", "Crosshair", .5f, .5f); }
    public boolean isVisible() { return ModuleManager.CROSSHAIR.isEnabled(); }
    public void setVisible(boolean visible) { ModuleManager.CROSSHAIR.setEnabled(visible); }
    protected void layout(boolean editing) { float s = ModuleManager.CROSSHAIR.size.get() * 2f + ModuleManager.CROSSHAIR.gap.get() * 2f + 8f; w=s; h=s; }
    protected void draw(DrawContext ctx, boolean editing) {
        var m=ModuleManager.CROSSHAIR; float cx=x+w/2f, cy=y+h/2f, size=m.size.get(), gap=m.gap.get(), t=m.thickness.get();
        int color = m.dynamic.get() && MinecraftClient.getInstance().targetedEntity != null ? 0xFFFF4D67 : VisualColors.get(m.color.get());
        Render2D.rect(ctx,cx-gap-size,cy-t/2f,size,t,t/2f,color); Render2D.rect(ctx,cx+gap,cy-t/2f,size,t,t/2f,color);
        Render2D.rect(ctx,cx-t/2f,cy-gap-size,t,size,t/2f,color); Render2D.rect(ctx,cx-t/2f,cy+gap,t,size,t/2f,color);
    }
}
