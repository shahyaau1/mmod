package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class JumpParticlesModule extends Module { public final ModeSetting style=add(new ModeSetting("Particle style","Spark","Ring","Dust","Slash")); public final ModeSetting color=add(new ModeSetting("Particle color",VisualModes.COLORS)); public final NumberSetting amount=add(new NumberSetting("Amount",16f,2f,40f,1f)); public JumpParticlesModule(){super("Jump Particles","Custom particles on jump and landing",Category.COMBAT);enableByDefault();} }
