package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.ModeSetting;
public final class KeystrokesModule extends Module {
    public final ModeSetting color = add(new ModeSetting("Keystrokes color", VisualModes.COLORS));
    public KeystrokesModule() { super("Keystrokes", "Клавиши движения и CPS", Category.COMBAT); enableByDefault(); }
}
