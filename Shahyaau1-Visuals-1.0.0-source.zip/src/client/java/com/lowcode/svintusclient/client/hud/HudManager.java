package dev.shahyaau1.visuals.client.hud;

import dev.shahyaau1.visuals.client.Shahyaau1VisualsClient;
import dev.shahyaau1.visuals.client.hud.widget.ArmorHudWidget;
import dev.shahyaau1.visuals.client.hud.widget.AdvancedCombatWidget;
import dev.shahyaau1.visuals.client.hud.widget.CoordinatesWidget;
import dev.shahyaau1.visuals.client.hud.widget.CrosshairWidget;
import dev.shahyaau1.visuals.client.hud.widget.KeystrokesWidget;
import dev.shahyaau1.visuals.client.hud.widget.ModuleListWidget;
import dev.shahyaau1.visuals.client.hud.widget.NotificationsWidget;
import dev.shahyaau1.visuals.client.hud.widget.TargetHudWidget;
import dev.shahyaau1.visuals.client.hud.widget.WatermarkWidget;
import dev.shahyaau1.visuals.client.module.ModuleManager;
import dev.shahyaau1.visuals.client.render.BlurEffect;
import dev.shahyaau1.visuals.client.render.Render2D;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class HudManager {

    private static final List<HudWidget> WIDGETS = new ArrayList<>();

    public static final WatermarkWidget WATERMARK = add(new WatermarkWidget());
    public static final ModuleListWidget MODULES = add(new ModuleListWidget());
    public static final CoordinatesWidget COORDINATES = add(new CoordinatesWidget());
    public static final TargetHudWidget TARGET = add(new TargetHudWidget());
    public static final ArmorHudWidget ARMOR = add(new ArmorHudWidget());
    public static final NotificationsWidget NOTIFICATIONS = add(new NotificationsWidget());
    public static final CrosshairWidget CROSSHAIR = add(new CrosshairWidget());
    public static final KeystrokesWidget KEYSTROKES = add(new KeystrokesWidget());
    public static final AdvancedCombatWidget ADVANCED_COMBAT = add(new AdvancedCombatWidget());

    private HudManager() {
    }

    private static <T extends HudWidget> T add(T widget) {
        WIDGETS.add(widget);
        return widget;
    }

    public static List<HudWidget> widgets() {
        return Collections.unmodifiableList(WIDGETS);
    }

    public static void register() {
        HudRenderCallback.EVENT.register(HudManager::render);
        HudEditor.register();
    }

    static boolean isActive(HudWidget widget) {
        if (!widget.isVisible()) return false;
        return widget == NOTIFICATIONS || ModuleManager.HUD.isEnabled();
    }

    static boolean isEditable(HudWidget widget) {
        return widget.isVisible() && (widget == NOTIFICATIONS || ModuleManager.HUD.isEnabled());
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        Render2D.setPixelScale((float) client.getWindow().getScaleFactor());
        Render2D.setAlpha(1f);
        if (ModuleManager.HUD.blur.get()) BlurEffect.capture(ctx);

        float guiScale = (float) client.getWindow().getScaleFactor();
        boolean editing = HudEditor.isEditing();
        float sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        for (HudWidget widget : WIDGETS) {
            if (!isActive(widget)) continue;
            widget.layout(editing);
            if (!HudEditor.isDragging(widget)) widget.place(sw, sh);
            Render2D.setPixelScale(guiScale * widget.scale);
            ctx.getMatrices().push();
            ctx.getMatrices().translate(widget.x, widget.y, 0);
            ctx.getMatrices().scale(widget.scale, widget.scale, 1);
            ctx.getMatrices().translate(-widget.x, -widget.y, 0);
            widget.draw(ctx, editing);
            ctx.getMatrices().pop();
        }
        Render2D.setPixelScale(guiScale);
        Render2D.setAlpha(1f);
    }
}
