package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class TrajectoryModule extends Module { public final ModeSetting color=add(new ModeSetting("Line color",VisualModes.COLORS)); public final BooleanSetting pearls=add(new BooleanSetting("Ender Pearl",true)); public final BooleanSetting arrows=add(new BooleanSetting("Arrows",true)); public final NumberSetting range=add(new NumberSetting("Range",32f,8f,80f,4f)); public TrajectoryModule(){super("Projectile Trajectory","Arrow and Ender Pearl prediction",Category.COMBAT);enableByDefault();} }
