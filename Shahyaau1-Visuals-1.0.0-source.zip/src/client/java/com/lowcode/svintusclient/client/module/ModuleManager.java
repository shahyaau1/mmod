package dev.shahyaau1.visuals.client.module;

import dev.shahyaau1.visuals.client.module.client.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {

    private static final List<Module> MODULES = new ArrayList<>();

    public static final ClickGuiModule CLICK_GUI = register(new ClickGuiModule());
    public static final HudModule HUD = register(new HudModule());
    public static final NotificationsModule NOTIFICATIONS = register(new NotificationsModule());
    public static final CrosshairModule CROSSHAIR = register(new CrosshairModule());
    public static final KeystrokesModule KEYSTROKES = register(new KeystrokesModule());
    public static final HitParticlesModule HIT_PARTICLES = register(new HitParticlesModule());
    public static final DamageNumbersModule DAMAGE_NUMBERS = register(new DamageNumbersModule());
    public static final JumpParticlesModule JUMP_PARTICLES = register(new JumpParticlesModule());
    public static final TrajectoryModule TRAJECTORY = register(new TrajectoryModule());
    public static final CombatInfoModule COMBAT_INFO = register(new CombatInfoModule());
    public static final ChinaHatModule CHINA_HAT = register(new ChinaHatModule());
    public static final EnvironmentVisualsModule ENVIRONMENT = register(new EnvironmentVisualsModule());
    public static final EntityVisualsModule ENTITY_VISUALS = register(new EntityVisualsModule());

    private ModuleManager() {
    }

    public static void init() {
    }

    public static <T extends Module> T register(T module) {
        MODULES.add(module);
        return module;
    }

    public static List<Module> all() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> byCategory(Category category) {
        return MODULES.stream().filter(m -> m.getCategory() == category).toList();
    }
}
