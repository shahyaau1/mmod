package dev.shahyaau1.visuals.client.render;

import net.minecraft.util.Identifier;

public record TextureSetup(Identifier texture) {
    public static TextureSetup empty() { return new TextureSetup(null); }
    public static TextureSetup of(Identifier texture) { return new TextureSetup(texture); }
}
