package dev.shahyaau1.visuals.client.render.icon;
import dev.shahyaau1.visuals.client.render.Render2D; import net.minecraft.client.gui.DrawContext;
public final class Icon { private final String name; Icon(String n,Svg s){name=n;} public void draw(DrawContext c,float x,float y,float z,int col){Render2D.rect(c,x+z*.2f,y+z*.2f,z*.6f,z*.6f,z*.15f,col);} public void drawCentered(DrawContext c,float x,float y,float z,int col){draw(c,x-z/2,y-z/2,z,col);} }
