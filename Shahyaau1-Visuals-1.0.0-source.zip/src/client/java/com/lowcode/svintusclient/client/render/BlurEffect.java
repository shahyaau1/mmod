package dev.shahyaau1.visuals.client.render;
import net.minecraft.client.gui.DrawContext;
public final class BlurEffect { private BlurEffect(){} public static void capture(DrawContext c){} public static boolean isReady(){return false;} public static TextureSetup setup(){return null;} }
