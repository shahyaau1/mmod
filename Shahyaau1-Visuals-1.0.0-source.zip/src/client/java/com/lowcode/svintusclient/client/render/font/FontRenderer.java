package dev.shahyaau1.visuals.client.render.font;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

/** Minecraft text renderer adapter with predictable left alignment and real size scaling. */
public final class FontRenderer {
    private static final float BASE = 9f;
    public FontRenderer(String name, String... resources) {}
    private net.minecraft.client.font.TextRenderer text() { return MinecraftClient.getInstance().textRenderer; }
    private float scale(float size) { return Math.max(.45f, size / BASE); }
    public float draw(DrawContext ctx, String value, float x, float y, float size, int color) {
        if (value == null || value.isEmpty()) return 0f;
        float s = scale(size);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(s, s, 1f);
        ctx.drawTextWithShadow(text(), value, 0, 0, color);
        ctx.getMatrices().pop();
        return width(value, size);
    }
    /** Draws from the supplied left x coordinate and vertically centers around centerY. */
    public float drawCentered(DrawContext ctx, String value, float x, float centerY, float size, int color) {
        return draw(ctx, value, x, centerY - height(size) / 2f, size, color);
    }
    public float drawGradient(DrawContext ctx, String value, float x, float centerY, float size, int from, int to) {
        return drawCentered(ctx, value, x, centerY, size, from);
    }
    public float width(String value, float size) { return text().getWidth(value == null ? "" : value) * scale(size); }
    public float height(float size) { return text().fontHeight * scale(size); }
    public String trim(String value, float size, float maxWidth) {
        return text().trimToWidth(value == null ? "" : value, Math.max(1, Math.round(maxWidth / scale(size))));
    }
    public List<String> wrap(String value, float size, float maxWidth) {
        List<String> out = new ArrayList<>(); StringBuilder line = new StringBuilder();
        for (String word : value.split(" ")) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (width(candidate, size) <= maxWidth || line.isEmpty()) line.replace(0, line.length(), candidate);
            else { out.add(line.toString()); line.replace(0, line.length(), word); }
        }
        if (!line.isEmpty()) out.add(line.toString());
        return out;
    }
}
