package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class EntityVisualsModule extends Module { public final ModeSetting nametagColor=add(new ModeSetting("Nametag color",VisualModes.COLORS)); public final ModeSetting glintColor=add(new ModeSetting("Glint color",VisualModes.COLORS)); public final BooleanSetting healthNametag=add(new BooleanSetting("Health nametag",true)); public final BooleanSetting cleanScoreboard=add(new BooleanSetting("Clean scoreboard",false)); public final BooleanSetting tabInfo=add(new BooleanSetting("Tab health / ping",true)); public EntityVisualsModule(){super("Entity Visuals","Nametags, tab, scoreboard and glint controls",Category.RENDER);enableByDefault();} }
