package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class ChinaHatModule extends Module { public final ModeSetting color=add(new ModeSetting("Hat color",VisualModes.COLORS)); public final NumberSetting radius=add(new NumberSetting("Radius",.65f,.2f,1.6f,.05f)); public final NumberSetting height=add(new NumberSetting("Height",.25f,.05f,.8f,.05f)); public ChinaHatModule(){super("China Hat","Camera-safe player hat ring",Category.RENDER);enableByDefault();} }
