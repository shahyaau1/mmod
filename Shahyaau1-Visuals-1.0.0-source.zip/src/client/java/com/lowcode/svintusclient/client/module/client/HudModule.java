package dev.shahyaau1.visuals.client.module.client;

import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.BooleanSetting;
import dev.shahyaau1.visuals.client.module.setting.NumberSetting;
import dev.shahyaau1.visuals.client.module.setting.ModeSetting;

public class HudModule extends Module {

    public final ModeSetting hudColor = add(new ModeSetting("HUD color", VisualModes.COLORS));

    public final BooleanSetting blur = add(new BooleanSetting("Размытие", true));
    public final NumberSetting glass = add(new NumberSetting("Плотность стекла", 0.62f, 0.45f, 0.95f, 0.05f));
    public final BooleanSetting watermark = add(new BooleanSetting("Ватермарка", true));
    public final BooleanSetting moduleList = add(new BooleanSetting("Список модулей", true));
    public final BooleanSetting coordinates = add(new BooleanSetting("Координаты", true));
    public final BooleanSetting targetHud = add(new BooleanSetting("Таргет HUD", true));
    public final BooleanSetting armorHud = add(new BooleanSetting("Броня", true));

    public HudModule() {
        super("HUD", "Элементы на экране. Открой чат, чтобы двигать", Category.CLIENT);
        enableByDefault();
    }
}
