package dev.shahyaau1.visuals.client.module.client;
import dev.shahyaau1.visuals.client.module.Category;
import dev.shahyaau1.visuals.client.module.Module;
import dev.shahyaau1.visuals.client.module.setting.*;
public final class CombatInfoModule extends Module { public final ModeSetting color=add(new ModeSetting("Info color",VisualModes.COLORS)); public final BooleanSetting reach=add(new BooleanSetting("Reach",true)); public final BooleanSetting combo=add(new BooleanSetting("Combo",true)); public final BooleanSetting cps=add(new BooleanSetting("CPS",true)); public final BooleanSetting sprint=add(new BooleanSetting("Sprint / Sneak",true)); public final BooleanSetting direction=add(new BooleanSetting("Direction",true)); public CombatInfoModule(){super("Combat Info","Reach, combo, CPS, sprint and direction",Category.COMBAT);enableByDefault();} }
