# PulseVisuals credits

В проект перенесены и адаптированы идеи и части реализации из:

https://github.com/Lopata12958/PulseVisuals

PulseVisuals распространяется под **MIT License**. Уведомление об авторских правах исходного проекта сохранено здесь для производной работы.

Copyright (c) 2025 PulseVisuals Contributors

The PulseVisuals source describes these visual features: hit particles, critical-hit feedback, damage numbers, target HUD and projectile trajectory prediction. The current Shahyaau1 Visuals implementation adapts these features to its own module/settings/HUD architecture and Minecraft 1.21.4 rendering API. Additional requested visuals, including selectable particle types, jump particles and China Hat, are implemented in Shahyaau1 Visuals.
