# PulseVisuals research

Source: https://github.com/Lopata12958/PulseVisuals

The repository README describes these visual blocks for Minecraft 1.21.4 Fabric:
- hit particles with separate normal/critical colors and lifetime/scale settings;
- target HUD with health, armor, name and distance;
- floating damage numbers with normal/critical/heal colors and fade animation;
- critical hit visual effect;
- projectile trajectory prediction with gravity and drag.

The repository LICENSE is MIT and says:
Copyright (c) 2025 PulseVisuals Contributors

Important implementation note: the checked-out repository contains placeholder render methods in parts of HitParticleRenderer, DamageNumberRenderer and TrajectoryRenderer. Shahyaau1 Visuals adapts the feature set into its own module/HUD architecture and implements the missing visual behavior for Fabric 1.21.4.
